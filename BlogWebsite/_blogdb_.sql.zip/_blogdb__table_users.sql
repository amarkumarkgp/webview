
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `date`, `role`) VALUES
(3, 'subash', 'spbairwa', 'sub@gmail.com', '$5$rounds=535000$E/ksizqcSn6g0e1m$SAKaCN2FqMZGKL741niE7XINIxB8pQJH4WGhYLZaf./', NULL, 'user'),
(4, 'amar', 'amarkumar', 'amarkumar@gmail.com', '$5$rounds=535000$vkCFYMcZz5qqlYIT$pksnmg5X4bqUfKnFmhjaGKcUBdRwzyptLohIqW5eIV3', NULL, 'user');
